import java.util.ArrayList;
import java.util.Collections;

public class BerkeleyClockSync {

    // The list of clocks to be synchronized
    private ArrayList<Long> clocks;

    public BerkeleyClockSync(ArrayList<Long> clocks) {
        this.clocks = clocks;
    }

    // Calculate the average time of the clocks
    private long calculateAverageTime() {
        long sum = 0;
        for (Long clock : clocks) {
            sum += clock;
        }
        return sum / clocks.size();
    }

    // Adjust the clocks to the average time
    private void adjustClocks(long averageTime) {
        for (int i = 0; i < clocks.size(); i++) {
            clocks.set(i, clocks.get(i) - averageTime);
        }
    }

    // Get the adjusted clocks
    public ArrayList<Long> getAdjustedClocks() {
        long averageTime = calculateAverageTime();
        adjustClocks(averageTime);
        return clocks;
    }

    // Get the time difference for each clock
    public ArrayList<Long> getTimeDifferences() {
        long averageTime = calculateAverageTime();
        ArrayList<Long> timeDifferences = new ArrayList<>();
        for (Long clock : clocks) {
            timeDifferences.add(clock - averageTime);
        }
        return timeDifferences;
    }

    public static void main(String[] args) {
        // Create the list of clocks
        ArrayList<Long> clocks = new ArrayList<>();
        clocks.add(10L);
        clocks.add(20L);
        clocks.add(30L);
        clocks.add(40L);

        // Create the clock synchronizer and get the adjusted clocks
        BerkeleyClockSync clockSync = new BerkeleyClockSync(clocks);
        ArrayList<Long> adjustedClocks = clockSync.getAdjustedClocks();

        // Print the adjusted clocks
        System.out.println("Adjusted Clocks: " + adjustedClocks);

        // Get the time differences for each clock
        ArrayList<Long> timeDifferences = clockSync.getTimeDifferences();

        // Sort the time differences
        Collections.sort(timeDifferences);

        // Calculate the median time difference
        long medianTimeDifference;
        if (timeDifferences.size() % 2 == 0) {
            medianTimeDifference = (timeDifferences.get(timeDifferences.size() / 2) + timeDifferences.get(timeDifferences.size() / 2 - 1)) / 2;
        } else {
            medianTimeDifference = timeDifferences.get(timeDifferences.size() / 2);
        }

        // Print the median time difference
        System.out.println("Median Time Difference: " + medianTimeDifference);
    }
}

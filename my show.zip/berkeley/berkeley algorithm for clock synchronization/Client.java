import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) throws IOException {
        String serverHostname = "localhost";
        int serverPort = 8000;

        Socket socket = new Socket(serverHostname, serverPort);

        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        int clientTime = (int) System.currentTimeMillis();
        out.println(clientTime);

        int serverTime1 = Integer.parseInt(in.readLine());
        int serverTime2 = Integer.parseInt(in.readLine());

        int timeDifference = serverTime2 - serverTime1;
        int synchronizedTime = clientTime + (timeDifference / 2);

        System.out.println("Client time: " + clientTime);
        System.out.println("Server time 1: " + serverTime1);
        System.out.println("Server time 2: " + serverTime2);
        System.out.println("Synchronized time: " + synchronizedTime);

        socket.close();
    }
}

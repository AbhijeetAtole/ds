import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8000);
        Socket clientSocket = serverSocket.accept();

        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

        int serverTime = 0;
        int clientTime = Integer.parseInt(in.readLine());
        out.println(serverTime);

        int timeDifference = clientTime - serverTime;
        serverTime += timeDifference / 2;

        out.println(serverTime);

        clientSocket.close();
        serverSocket.close();
    }
}

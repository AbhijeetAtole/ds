import java.rmi.Naming;
import java.util.Scanner;

public class GCDClient {

    public static void main(String[] args) {
        try {
            // Get user input for the numbers
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the first number: ");
            int number1 = scanner.nextInt();
            System.out.print("Enter the second number: ");
            int number2 = scanner.nextInt();

            // Lookup the remote server object
            GCDInterface gcdServer = (GCDInterface) Naming.lookup("rmi://localhost/GCDServer");

            // Call the remote method
            int result = gcdServer.calculateGCD(number1, number2);
            System.out.println("GCD: " + result);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

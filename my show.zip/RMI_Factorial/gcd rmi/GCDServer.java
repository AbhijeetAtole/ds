import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class GCDServer extends UnicastRemoteObject implements GCDInterface {

    public GCDServer() throws RemoteException {
        super();
    }

    @Override
    public int calculateGCD(int a, int b) throws RemoteException {
        if (b == 0) {
            return a;
        } else {
            return calculateGCD(b, a % b);
        }
    }

    public static void main(String[] args) {
        try {
            GCDServer server = new GCDServer();
            // Bind the server object to the RMI registry
            java.rmi.registry.Registry registry = java.rmi.registry.LocateRegistry.createRegistry(1099);
            registry.rebind("GCDServer", server);
            System.out.println("GCDServer is running...");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
